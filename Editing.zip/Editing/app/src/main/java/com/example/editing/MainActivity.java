package com.example.editing;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ScrollView;
import android.widget.SeekBar;

import androidx.annotation.RequiresApi;

import java.util.ArrayList;
import java.util.List;

import ja.burhanrashid52.photoeditor.PhotoEditor;
import ja.burhanrashid52.photoeditor.PhotoEditorView;

public class MainActivity extends Activity {
    ImageButton AddTextButton;
    ImageButton AddIconButton;
    ImageButton DrawButton;
    PhotoEditor mPhotoEditor;
    PhotoEditorView mPhotoEditorView;

    GridView EmojigridView;

    ScrollView BrushScrollView;

    SeekBar BrushWeight;

    SeekBar BrushOpacity;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AddTextButton = (ImageButton) findViewById(R.id.addTextButton);

        mPhotoEditorView = findViewById(R.id.photoEditorView);

        mPhotoEditorView.getSource().setImageResource(R.drawable.place_holder);

        mPhotoEditor = new PhotoEditor.Builder(this, mPhotoEditorView)
                .setPinchTextScalable(true)
                .build();
        //R.layout.emojis_list_row
        final List<String> Emojis = PhotoEditor.getEmojis(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, Emojis);

        EmojigridView = (GridView) findViewById(R.id.EmojiList);
        EmojigridView.setAdapter(adapter);


        AddIconButton = (ImageButton) findViewById(R.id.addIconButton);
        DrawButton = (ImageButton) findViewById(R.id.drawButton);

        AddIconButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(EmojigridView.getVisibility() == View.VISIBLE)
                {
                    EmojigridView.setVisibility(View.INVISIBLE);
                }
                else
                {
                    EmojigridView.setVisibility(View.VISIBLE);
                }
            }
        });

        BrushScrollView = (ScrollView) findViewById(R.id.BrushCustomize);
        BrushWeight = (SeekBar) findViewById(R.id.brush_weight);
        BrushWeight.setMax(100);
        BrushWeight.setMin(5);
        BrushWeight.setProgress(20);

        BrushOpacity = (SeekBar) findViewById(R.id.brush_opacity);
        BrushOpacity.setMax(100);
        BrushOpacity.setMin(5);
        BrushOpacity.setProgress(20);



        DrawButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (BrushScrollView.getVisibility() == View.INVISIBLE)
                {
                    BrushScrollView.setVisibility(View.VISIBLE);
                    mPhotoEditor.setBrushDrawingMode(true);
                    mPhotoEditor.setBrushSize(BrushWeight.getProgress());
                    mPhotoEditor.setOpacity(BrushOpacity.getProgress());
                    BrushWeight.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                        int progress = 0;
                        @Override
                        public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                            progress = i;
                            mPhotoEditor.setBrushSize(i);
                        }

                        @Override
                        public void onStartTrackingTouch(SeekBar seekBar) {

                        }

                        @Override
                        public void onStopTrackingTouch(SeekBar seekBar) {
                            mPhotoEditor.setBrushSize(progress);
                        }
                    });
                    BrushOpacity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                        int progress;
                        @Override
                        public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                            progress = i;
                            mPhotoEditor.setOpacity(i);
                        }

                        @Override
                        public void onStartTrackingTouch(SeekBar seekBar) {

                        }

                        @Override
                        public void onStopTrackingTouch(SeekBar seekBar) {

                        }
                    });
                }
                else
                {
                    BrushScrollView.setVisibility(View.INVISIBLE);
                    mPhotoEditor.setBrushDrawingMode(false);
                }
            }
        });

        EmojigridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                mPhotoEditor.addEmoji(Emojis.get(i));
            }
        });

    }
}
